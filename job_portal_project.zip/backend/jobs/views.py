from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Job

@api_view(['POST'])
def create_job(request):
    Job.objects.create(
        employer=request.user,
        title=request.data['title'],
        description=request.data['description'],
        location=request.data['location'],
        salary=request.data['salary']
    )
    return Response({'message': 'Job created'})
