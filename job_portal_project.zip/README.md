# Job Portal Web Application

Python Full Stack Job Portal using Django and Django REST Framework.
